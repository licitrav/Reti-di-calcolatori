import json
import socket
import struct
import threading
import os
import sys
import json
MAX_CLIENTS = 10
#Classe client (Ip udp,porta udp,Username,password)  fatto
 #Funzione registrazione/*login facendo una ricerca nel file fatto
#
#Array client online fatto
#Modo per pulire l'array
#File Json che memorizza tiene tutti i client registrati fatto
#Ricerca utente nel client, send al client
#Invio messaggi in udp,Registrazione in tcp
        


class client:
    def __init__(self,ip,port,username):
        self.ip=ip
        self.port=port
        self.username=username


onlineUsers=[]

def findUser(user):
    for c in onlineUsers:
        if c.username==user:
            return True
    return False


def autenticazione(username, password):
    utenti = []

    # Carica utenti se file esiste
    if os.path.exists("utenti.json") and os.path.getsize("utenti.json") > 0:
        with open("utenti.json", "r") as filejson:
            utenti = json.load(filejson)

        # Cerco l'utente per login
        for cliente in utenti:
            if cliente["username"] == username:
                if cliente["password"] == password:
                    print("Login riuscito")
                    return True
                else:
                    print("Password errata")
                    return False

        # Se arrivo qui, utente non trovato: lo registro
        new_utente = {"username": username, "password": password}
        utenti.append(new_utente)
        with open("utenti.json", "w") as filejson:
            json.dump(utenti, filejson, indent=4)
        print("Registrazione completata")
        return True

    else:
        # File non esiste o vuoto: creo lista e aggiungo utente
        new_utente = {"username": username, "password": password}
        utenti.append(new_utente)
        with open("utenti.json", "w") as filejson:
            json.dump(utenti, filejson, indent=4)
        print("Registrazione completata")
        return True
                       

def handle_client(sock):
   #Smistare i messaggi
   samplePack="!20s255s20s"
   while True: 
    packData,addr=sock.recvfrom(1024)
    username2,message,dest=struct.unpack(samplePack,packData)
    message=message.decode().strip('\x00')
        #Decodifica i dati ricevuti
    username2=username2.decode().strip('\x00')
    dest=dest.decode().strip('\x00')
    if message=="/reg":
        if findUser(username2):
            print("Utente già online")
            continue
        else:
            newUser= client(addr[0],addr[1],username2)
            print(newUser)
            onlineUsers.append(newUser)
            print("User aggiunto")
        #Invio direttamente il messaggio
    elif message=="/exit":
        for user in onlineUsers:
            if user.username == username2:
                print("Utente rimosso")
                onlineUsers.remove(user)
                break 
    else:
        for user in onlineUsers:
                if user.username==dest:
                    sock.sendto(packData,(user.ip,user.port))
                    print("Messaggio inviato a",dest)

    
        #invio del messaggio
        if findUser(username2):
        #Invio direttamente il messaggio
            for user in onlineUsers:
                if user.username==dest:
                    sock.sendto(packData,(user.ip,user.port))
                    print("messaggio inviato a",dest)
            
   
def Server_message():
    if len(sys.argv)<4:
        print("Servono ip e port del serverMessage")
        return
    server_ip= sys.argv[1]
    server_port=int(sys.argv[2])
    server_portudp=int(sys.argv[3])
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((server_ip,server_portudp))
  

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  
    server_socket.bind((server_ip, int(server_port)))

   # configure how many client the server can listen simultaneously
    server_socket.listen(MAX_CLIENTS)

    while True:
       samplePack="!20s20s"  
       # The server continuously listens for incoming client connections.
       client_socket, address = server_socket.accept()
       print("Connection from: " + str(address))
       packedData=client_socket.recv(1024)
       username,password=struct.unpack(samplePack,packedData)
       username=username.decode().strip('\x00')
       password=password.decode().strip('\x00')
       if autenticazione(username,password):
           print("Invio risposta")
           reply=struct.pack("!20s",b'true')
           client_socket.sendall(reply)
           client_thread = threading.Thread(target=handle_client, args=(sock,))
           client_thread.start()
       else:
           reply=struct.pack("!20s",b'false')
           client_socket.sendall(reply)
           print("Autenticazione fallita")
       # When a new client connects, a new thread is created to handle the client.
       
  
    conn.close()  # close the connection

if __name__ == '__main__':
   Server_message()
