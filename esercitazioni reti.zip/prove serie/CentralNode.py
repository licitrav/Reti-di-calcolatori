import socket
import threading
import pickle
import  sys
import random
from sensore import sensore
# array che salva i sensori
#connessione con il controlNode
#funziona che gestisce i messagi da controlnode a sensore
MAX_CLIENTS = 24
class idsens:
   def __init__(self,id,socket):
      self.id=id
      self.socket=socket
      pass
sensori= []
def handle_control(control):
   while True:
      data = control.recv(1024)
      unpack=pickle.loads(data)
      print(unpack)
      if not data:
         # if data is not received break
         control.close()
         return
      print("Ricevuto dal control node",unpack)
      for sensor in sensori:
         print(sensor.id)
         if sensor.id==unpack:
            sensor.socket.sendall(b'backnormal')
            break
         else:
            print("Non ho trovato il sensore")

def handle_client(client_socket,controlSocket):
   # receive data stream.
   while True:   
      data = client_socket.recv(1024)
      if not data:
         # if data is not received break
         client_socket.close()
         return
      unpackedData= pickle.loads(data)
      print("from connected user: ",unpackedData.temperatura,unpackedData.umidità,unpackedData.qualAir)
      if unpackedData.temperatura>30 or unpackedData.qualAir<30:
         controlSocket.sendall(data)
      

def server_program():
   if len(sys.argv)<5:
      print("Inserire numero Ip,porta di questo nodo e del control node")
   host = sys.argv[1]
   port = int(sys.argv[2])
   server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  
   server_socket.bind((host, port))
   # configure how many client the server can listen simultaneously
   server_socket.listen(MAX_CLIENTS)
   #socket per il control node
   node = sys.argv[3] 
   portn = int(sys.argv[4])

   node_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # instantiate
   node_socket.connect((node, portn))
   while True:
       # The server continuously listens for incoming client connections.
       client_socket, address = server_socket.accept()
       print("Connection from: " + str(address))
       packId=client_socket.recv(1024)
       unpackId=pickle.loads(packId)
       for i in range(len(sensori)):
        if i<=len(sensori)and sensori[i].id== unpackId:
            unpackId=random.randint(1000,5000)
            i=0
       newID=pickle.dumps(unpackId)
       client_socket.sendall(newID)
       newSensor= idsens(unpackId,client_socket)
       sensori.append(newSensor)
       # When a new client connects, a new thread is created to handle the client.
       client_thread = threading.Thread(target=handle_client, args=(client_socket,node_socket,))
       client_thread.start()
       node_thread=threading.Thread(target=handle_control,args=(node_socket,))
       node_thread.start()
   conn.close()  # close the connection

if __name__ == '__main__':
   server_program()

