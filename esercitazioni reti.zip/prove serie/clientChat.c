#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include "chat_message.h"

#define MAX_LEN 20



struct {
    char username[MAX_LEN];
    char password[MAX_LEN];
}typedef user;


int sockfd,socktcp;
struct sockaddr_in server_addr;
user userP;

void *receive_handler(void *arg) {
   chat_message msg;
   struct sockaddr_in from_addr;
   socklen_t addr_len = sizeof(from_addr);
  
   while(1) {
       ssize_t bytes = recvfrom(sockfd, &msg, sizeof(msg), 0,
                              (struct sockaddr*)&from_addr, &addr_len);
       if(bytes == sizeof(msg)) {
           printf("\n[%s] %s\n> ", msg.mittente, msg.message);
           fflush(stdout);
       }
   }
   return NULL;
}
void send_message(const char *text,const char *dest) {
   chat_message msg;
   memset(&msg, 0, sizeof(msg));
   strncpy(msg.mittente, userP.username, MAX_LEN);
   strncpy(msg.message, text, 255);
   strncpy(msg.destinatario,dest,MAX_LEN);
   
  
   sendto(sockfd, &msg, sizeof(msg), 0,
          (struct sockaddr*)&server_addr, sizeof(server_addr));
}

int main(int argc, char * argv[]) {
    if(argc<4){
        printf("Inserire IP, porta tc e porta udp");
        return 1;
    }
    //Socket UDP
   sockfd = socket(AF_INET, SOCK_DGRAM, 0);
   if(sockfd < 0) {
       perror("socket failed");
       return 1;
   }
   memset(&server_addr, 0, sizeof(server_addr));
   server_addr.sin_family = AF_INET;
   server_addr.sin_port = htons(atoi(argv[3]));
   inet_pton(AF_INET, argv[1], &server_addr.sin_addr);
   int socktcp;
   struct sockaddr_in serv_addrtcp;

   // create socket (ip, using TCP)
   if ((socktcp = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
       perror("socket creation failed");
       exit(1);
   }
    memset(&serv_addrtcp, 0, sizeof(serv_addrtcp));
   serv_addrtcp.sin_family = AF_INET;
   serv_addrtcp.sin_port = htons(atoi(argv[2]));

   // convert IP address from text to binary form
   if (inet_pton(AF_INET, argv[1], &serv_addrtcp.sin_addr) <= 0) {
       perror("invalid address");
       exit(1);
   }
    memset(&serv_addrtcp, 0, sizeof(serv_addrtcp));
   serv_addrtcp.sin_family = AF_INET;
   serv_addrtcp.sin_port = htons(atoi(argv[2]));

   // convert IP address from text to binary form
   if (inet_pton(AF_INET, argv[1], &serv_addrtcp.sin_addr) <= 0) {
       perror("invalid address");
       exit(1);
   }
   if (connect(socktcp, (struct sockaddr *)&serv_addrtcp, sizeof(serv_addrtcp)) < 0) {
       perror("connection failed");
       exit(1);
   }

   printf("Connected to %s:%s\n", argv[1], argv[2]);
   printf("Type messages (enter 'exit' to quit):\n");
  


   printf("Enter nickname: ");
   fgets(userP.username, MAX_LEN, stdin);
   userP.username[strcspn(userP.username, "\n")] = '\0';
   printf("Enter password: ");
   fgets(userP.password, MAX_LEN, stdin);
   userP.password[strcspn(userP.password, "\n")] = '\0';
   // Register with server
   send(socktcp,&userP,sizeof(user),0);
   char resp[20];
   recv(socktcp,&resp,sizeof(resp),0);
   if(strncmp(resp,"true",20)==0){
        printf("Accesso eseguito\n");
   }
   else{
    printf("Fallito hai fallito EHEHEH\n");
    return -1;
   }
    //Connessione UDP  
   // Start receive thread
   pthread_t recv_thread;
   pthread_create(&recv_thread, NULL, receive_handler, NULL);
   int checkFirst=0; 
   printf("Connected! Type messages (/exit to quit)\n> ");
   while(1) {
        printf("Inserisci destinatario\n");
       char input[MAX_LEN];
       fgets(input, MAX_LEN, stdin);
       input[strcspn(input, "\n")] = '\0';
       printf("Inserisci messaggio, se hai appena fatto login, scrivi /reg  per aggiungerti alla lista\n");
        
       char mex[255];
       fgets(mex, 255, stdin);
       mex[strcspn(mex, "\n")] = '\0';
       if(strcmp(mex,"/reg")!=0&& checkFirst==0){
        printf("Nun fari u spettu e mettici u destinatariu\n");
       }
       if(strcmp(mex,"/reg")==0&& checkFirst==0){
        printf("registrazione in corso\n");
        checkFirst=1;
        send_message(mex,"/reg");  // Send registration command
       }
       
       else if(strcmp(input, "/exit") == 0) {
           send_message("/exit","");  // Send exit command
           break;
       }
       else send_message(mex,input);  // Send normal message
   }

   close(sockfd);
   return 0;
}
