class calc:
    def __init__(self,command,op1,op2,operazione,portC,IPc,IDc):
        self.command=int(command)
        self.op1=int(op1)
        self.op2=int(op2)
        self.operazione=str(operazione)
        self.portC=int(portC)
        self.IPc=IPc
        self.IDc=IDc
        