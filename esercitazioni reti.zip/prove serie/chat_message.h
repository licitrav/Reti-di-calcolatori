#pragma pack(push,1)
struct 
{
    char mittente[20];
    char message[255];
    //char destinatario[20];

}typedef chat_message;

#pragma pack(pop)