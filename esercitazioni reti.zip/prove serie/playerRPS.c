/*
struct email,password
una serie di stati, attesa lobby partita
attesa=può scollegarsi o aspettare
lobby=può rigiocare immediatamente o scollegarsi
partità fa la sua mossa

*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define BUFFER_SIZE 30
struct{
    char email[30];
    char password[30];
}typedef player;

int main(int argc, char* argv[]) {

   if(argc <3){
       //remember, argv[0] is the same program!
       fprintf(stderr, "Usage: %s <IP> <Port>\n", argv[0]);
       exit(1);
   }

   player p;
   int sockfd;
   struct sockaddr_in serv_addr;
   memset(&p, 0, sizeof(p));  // pulisce tutti i byte


   // create socket (ip, using TCP)
   if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
       perror("socket creation failed");
       exit(1);
   }

   memset(&serv_addr, 0, sizeof(serv_addr));
   serv_addr.sin_family = AF_INET;
   serv_addr.sin_port = htons(atoi(argv[2]));

   // convert IP address from text to binary form
   if (inet_pton(AF_INET, argv[1], &serv_addr.sin_addr) <= 0) {
       perror("invalid address");
       exit(1);
   }

  // connect to server
   if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
       perror("connection failed");
       exit(1);
   }

   printf("Connected to %s:%s\n", argv[1], argv[2]);
   printf("Autenticazione inserire mail\n");
   fgets(p.email,30, stdin);
   p.email[strcspn(p.email, "\n")] = '\0';
   printf("Inserire password: ");
   fgets(p.password, 30, stdin);
   p.password[strcspn(p.password, "\n")] = '\0';
   printf("%s , %s invio dati",p.email,p.password);
   if (send(sockfd, &p, sizeof(p), 0) < 0) {
           perror("send failed");
           
       }
    
    int number;
    char risposta;
    int bytes_received = recv(sockfd, &number, sizeof(int), 0);
    number=ntohl(number);
    printf("Numero ricevuto %d\n",number);
    if (bytes_received <= 0) {
           perror("recv failed");
           return -1;
       }
    if(number==1){
        printf("Devi attendere un altro giocatore vuoi attendere o chiudi la connessione digia s o n\n"); 
        scanf("%c",&risposta);
        getchar();
        printf("Sto inviando %c \n",risposta);
        send(sockfd,&risposta,sizeof(char),0);
        if(risposta=='n'){
            send(sockfd,&risposta,sizeof(char),0);
            close(sockfd);
            return 1;
        }
        for(;;){
                int bytes_received = recv(sockfd, &number, sizeof(int), 0);
                if (bytes_received <= 0) {
                perror("recv failed");
                return -1;
                }
                bytes_received=ntohl(bytes_received);        
                if(number>=2){
                    printf("Stiamo entrando in partita\n");
                    break;
                }
            }
    }
        
    if(number>=2){
        while(1) { // ciclo esterno: sessioni partita
            int vittorie=0;
            int sconfitte=0;
            while(number<2){
                int bytes_received = recv(sockfd, &number, sizeof(int), 0);
                if (bytes_received <= 0) {
                    perror("recv failed");
                    return -1;
                }
                number=ntohl(number);
                if(number>=2){
                    printf("Stiamo entrando in partita\n");
                    break;
                }
            }
            while(vittorie<3 && sconfitte<3) { // ciclo interno: turni
                char buffer[30];
                memset(buffer,0,sizeof(buffer)); 
                printf("inserire sasso,carta,forbice\n");
                fgets(buffer,30, stdin);
                buffer[strcspn(buffer, "\n")] = '\0';
                if (send(sockfd, buffer, strlen(buffer), 0) < 0) {
                    perror("send failed");
                    break;
                }
                memset(buffer,0,30);
                int bytes_received = recv(sockfd, buffer, BUFFER_SIZE - 1, 0);
                if (bytes_received < 0) {
                    perror("recv failed");
                    break;
                } else if (bytes_received == 0) {
                    printf("Server closed connection\n");
                    break;
                }
                printf("Il risultato del turno è: %s\n", buffer);
                if(strcmp(buffer,"win")==0) vittorie++;
                else if(strcmp(buffer,"lose")==0) sconfitte++;
                else continue;
            }
            printf("Hai vinto\n");
            if(vittorie<sconfitte) printf("Hai perso\n");
            printf("Vuoi giocare nuovamente? digita s o n\n");
            scanf("%c",&risposta);
            getchar();
            send(sockfd,&risposta,sizeof(char),0);
            if(risposta!='s') break;
            // Attendi che il server ti rimetta in partita
            int bytes_received = recv(sockfd, &number, sizeof(int), 0);
            if (bytes_received <= 0) {
                perror("recv failed");
                break;
            } 
            number = ntohl(number);
            if(number < 2) {
                printf("In attesa di un nuovo avversario...\n");
                continue;
            }
            printf("Nuova partita iniziata!\n");
        }
    }
  

   

   close(sockfd);
   return 0;
}

