class sensore:
    def __init__(self, temperatura,umidità,qualAir,id):
        self.temperatura=temperatura
        self.umidità=umidità
        self.qualAir=qualAir
        self.id=id
        pass