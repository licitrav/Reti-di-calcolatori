import json
import pickle
import sys
import socket
import os
import threading
import time
from sensore import sensore
MAX_CLIENTS = 1
sensori=[]
def invio(socket,id):
     time.sleep(5)
     packid=pickle.dumps(id)
     socket.sendall(packid)
     
def server_program():
   if len(sys.argv)<3:
       print("Metti ip e porta del controlNode")
       return
   host = sys.argv[1]
   port = int(sys.argv[2])
   server_socket = socket.socket()  # get instance
   # look closely. The bind() function takes tuple as argument
   server_socket.bind((host, port))

   # configure how many client the server can listen simultaneously
   server_socket.listen(MAX_CLIENTS)
   # conn is the client socket file descriptor
   conn, address = server_socket.accept()  # accept new connection
   print("Connection from: " + str(address))
   
   while True:
       # receive data stream. it won't accept data packet greater than 1024 bytes
       data = conn.recv(1024)
       
       if not data:
           # if data is not received break
           break
       unpackedata= pickle.loads(data)
       print("from connected user: " , unpackedata.temperatura,unpackedata.umidità,unpackedata.qualAir,unpackedata.id)
       new_sensore = {"temperatura": unpackedata.temperatura, "umid": unpackedata.umidità,"qualAir": unpackedata.qualAir,"Id":unpackedata.id}
       sensori.append(new_sensore)
       with open("sensori.json", "w") as filejson:
                json.dump(sensori, filejson, indent=4)
                print("Registrazione  log completata")
                
       timer=threading.Thread(target=invio,args=(conn,unpackedata.id,))
       print("thread creato")

       timer.start()

       
        # send data to the client

   conn.close()  # close the connection


if __name__ == '__main__':
   server_program()
