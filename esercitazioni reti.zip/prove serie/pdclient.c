#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define INF_SIZE 30

struct
{
    char email[INF_SIZE];
    char password[INF_SIZE];
}typedef player;
struct
{
    int num;
    char risp;
}typedef ACK;


int sockfd;  // global socket descriptor for thread access


int main(int argc, char *argv[]) {

   struct sockaddr_in serv_addr;
    

   // create socket (ip, using TCP)
   if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
       perror("socket creation failed");
       exit(1);
   }

   memset(&serv_addr, 0, sizeof(serv_addr));
   serv_addr.sin_family = AF_INET;
   serv_addr.sin_port = htons(atoi(argv[2]));

   // convert IP address from text to binary form
   if (inet_pton(AF_INET, argv[1], &serv_addr.sin_addr) <= 0) {
       perror("invalid address");
       exit(1);
   }
      if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
       perror("connection failed");
       exit(1);
   }
   player pl;
   memset(pl.email,0,INF_SIZE);
   memset(pl.password,0,INF_SIZE);
   printf("Connected to %s:%s\n", argv[1], argv[2]);
   printf("Benvenuto nel server pari o dispari, inserisci le tue credenziali, se non sei registrato,verrai registrato in automatico\n");
   printf("Bene immeti la tua email\n");
   fgets(pl.email,INF_SIZE,stdin);
   pl.email[strcspn(pl.email, "\n")] = '\0';
   printf("Ottimo ora la password\n");
   fgets(pl.password,INF_SIZE,stdin);
   pl.password[strcspn(pl.password, "\n")] = '\0';
   printf("Vediamo se puoi giocare....\n");
   send(sockfd,&pl,sizeof(pl),0);
   ACK resp;
   recv(sockfd,&resp.num,sizeof(resp.num),0);
   recv(sockfd,&resp.risp,sizeof(resp.risp),0);
   if(resp.risp=='s'||resp.risp=='r'){
        if(resp.risp=='s') printf("Login eseguito bentornato\n");
        else printf("Registrazione effettuata,benvenuto\n");
        }
   else{
    printf("Errore riprovare\n");
    close(sockfd);
    return 0;
   }
   int num=0;
   for(;;){
        if(resp.num==1){
            printf("Sei al momento solo vuoi metterti in attesa? Digita s o n\n");
            scanf("%c",&resp.risp);
            getchar();
            if(resp.risp=='s'){
                send(sockfd,&resp.risp,sizeof(char),0);
                for(;;){
                printf("Sei in attesa del tuo avversario\n");
                recv(sockfd,&resp.num,sizeof(resp),0);
                if(resp.num==2) break;
                }
            }
            else{
                printf("Ok chiudiamo il collegamento\n");
                send(sockfd,&resp.risp,sizeof(char),0);
                close(sockfd);
                return 0;
            }
        }
        printf("Inizio la partita\n");
        int vittoria=0;
        int sconfitta=0;
        printf("Scelta se sei paro o disparo\n");
        recv(sockfd,&resp.risp,sizeof(char),0);
        if(resp.risp=='p') printf("Sei pari!\n");
        else if(resp.risp=='d') printf("Sei dispari!\n");
        while(vittoria>=3||sconfitta>=3){
            printf("Digitare un numero da un numero\n");
            scanf("%d",&num);
            getchar();
                if(num<1||num>10){
                    printf("A si bestia?? Ta rittu da 1 a 10\n");
                }
            else{
                printf("Invio i dati, in attesa di risultati\n");
                send(sockfd,&num,sizeof(int),0);
                recv(sockfd,&resp.risp,sizeof(char),0);
                if(resp.risp=='w'){
                    printf("Round vinto\n");
                    vittoria++;
                }
                else {
                    printf("Round perso");
                    sconfitta++;
                }
            }
        }
        printf("Parità finita\n");
        if(vittoria>=3){
        printf("Congratulazioni hai vinto\n");
            }
        else{
            printf("AHAHAHA HAI PERSO!!!!\n");
            }
        printf("Se vuoi continuare digita s, altrimenti n");
        scanf("%c",&resp.risp);
        getchar();
        send(sockfd,&resp.risp,sizeof(char),0);
        if(resp.risp=='s'){
             printf("Ottimo si rigioca");
             recv(sockfd,&resp.num,sizeof(int),0);
            }
        else{
            printf("Ok arrivederci\n");
            break;
        }

   }


   close(sockfd);
   return 0;
}

