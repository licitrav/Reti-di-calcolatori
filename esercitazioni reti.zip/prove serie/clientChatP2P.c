#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include "chat_message.h"

#define MAX_LEN 20



struct {
    char username[MAX_LEN];
    char password[MAX_LEN];
    int port;
}typedef user;

struct {
    char ip[32];
    int port;
}typedef destinatario;
int sockfd,socktcp;
struct sockaddr_in peer_addr;
struct sockaddr_in peer_mia;
user userP;

void *receive_handler(void *arg) {
   chat_message msg;
   struct sockaddr_in from_addr;
   socklen_t addr_len = sizeof(from_addr);
  
   while(1) {
       ssize_t bytes = recvfrom(sockfd, &msg, sizeof(msg), 0,
                              (struct sockaddr*)&from_addr, &addr_len);
       if(bytes == sizeof(msg)) {
           printf("\n[%s] %s\n> ", msg.mittente, msg.message);
           fflush(stdout);
       }
   }
   return NULL;
}
void send_message(char *ip, int portDest) {
    memset(&peer_addr, 0, sizeof(peer_addr));
    peer_addr.sin_family = AF_INET;
    inet_pton(AF_INET, ip, &peer_addr.sin_addr);
    peer_addr.sin_port = htons(portDest);

    for(;;){
        chat_message msg;
        printf("Inserisci messaggio, se hai appena fatto login, scrivi /reg  per aggiungerti alla lista\n");    
        char mex[255];
        fgets(mex, 255, stdin);
        mex[strcspn(mex, "\n")] = '\0';
        strncpy(msg.mittente, userP.username, MAX_LEN);
        strncpy(msg.message, mex, 255);

        if(strcmp(mex, "/exit") == 0) {
            sendto(sockfd, &msg, sizeof(msg), 0, (struct sockaddr*)&peer_addr, sizeof(peer_addr));
            break;
        }
        sendto(sockfd, &msg, sizeof(msg), 0, (struct sockaddr*)&peer_addr, sizeof(peer_addr));
    }
}

int main(int argc, char * argv[]) {
    if(argc<5){
        printf("Inserire IP, porta tcp del server e il tuo ip la tua porta di ricezione udp\n");
        return 1;
    }
    //Socket UDP
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if(sockfd < 0) {
        perror("socket failed");
        return 1;
    }
    memset(&peer_mia, 0, sizeof(peer_mia));
    peer_mia.sin_family = AF_INET;
    inet_pton(AF_INET, argv[3], &peer_mia.sin_addr);
    peer_mia.sin_port = htons(atoi(argv[4]));
    if(bind(sockfd, (struct sockaddr*)&peer_mia, sizeof(peer_mia)) < 0) {
        perror("bind failed");
        return 2;
    }
    //Socket TCP
   int socktcp;
   struct sockaddr_in serv_addrtcp;

   // create socket (ip, using TCP)
   if ((socktcp = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
       perror("socket creation failed");
       exit(1);
   }
    memset(&serv_addrtcp, 0, sizeof(serv_addrtcp));
   serv_addrtcp.sin_family = AF_INET;
   serv_addrtcp.sin_port = htons(atoi(argv[2]));

   // convert IP address from text to binary form
   if (inet_pton(AF_INET, argv[1], &serv_addrtcp.sin_addr) <= 0) {
       perror("invalid address");
       exit(1);
   }
    memset(&serv_addrtcp, 0, sizeof(serv_addrtcp));
   serv_addrtcp.sin_family = AF_INET;
   serv_addrtcp.sin_port = htons(atoi(argv[2]));

   // convert IP address from text to binary form
   if (inet_pton(AF_INET, argv[1], &serv_addrtcp.sin_addr) <= 0) {
       perror("invalid address");
       exit(1);
   }
   //Inizializzazione peer_mia
   

   if (connect(socktcp, (struct sockaddr *)&serv_addrtcp, sizeof(serv_addrtcp)) < 0) {
       perror("connection failed");
       exit(1);
   }

   printf("Connected to %s:%s\n", argv[1], argv[2]);
   printf("Type messages (enter 'exit' to quit):\n");
  


   printf("Enter nickname: ");
   fgets(userP.username, MAX_LEN, stdin);
   userP.username[strcspn(userP.username, "\n")] = '\0';
   printf("Enter password: ");
   fgets(userP.password, MAX_LEN, stdin);
   userP.password[strcspn(userP.password, "\n")] = '\0';
   userP.port=htonl(atoi(argv[4]));
   // Register with server
   send(socktcp,&userP,sizeof(user),0);
   char resp[20];
   recv(socktcp,&resp,sizeof(resp),0);
   if(strncmp(resp,"true",20)==0){
        printf("Accesso eseguito\n");
   }
   else{
    printf("Fallito hai fallito EHEHEH\n");
    return -1;
   }
    //Connessione UDP  
   // Start receive thread
   pthread_t recv_thread;
   pthread_create(&recv_thread, NULL, receive_handler, NULL);
   
   printf("Connected! Type messages (/exit to quit)\n> ");
   while(1) {
        printf("Inserisci destinatario\n");
       char input[MAX_LEN];
       fgets(input, MAX_LEN, stdin);
       input[strcspn(input, "\n")] = '\0';
       char desti[20];
       memset(desti,0,sizeof(desti));
       strncpy(desti,input, sizeof(desti) - 1);
       send(socktcp,&desti,sizeof(desti),0);
        destinatario dest;
        recv(socktcp, dest.ip, 20, 0); // ricevi i 20 byte dell'IP
        recv(socktcp, &dest.port, sizeof(int), 0); // ricevi la porta   
        dest.port = ntohl(dest.port); // conversione da network a host order
        dest.ip[19] = '\0';
        printf("La porta scelta à la: %d",dest.port);
        send_message(dest.ip, dest.port);  // Send normal message
   }

   close(sockfd);
   return 0;
}
