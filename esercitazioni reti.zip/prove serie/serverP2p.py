import json
import socket
import struct
import threading
import os
import sys
import json
MAX_CLIENTS = 10

        


class client:
    def __init__(self,ip,port,username):
        self.ip=ip
        self.port=port
        self.username=username


onlineUsers=[]

def findUser(user):
    for c in onlineUsers:
        if c.username==user:
            return True
    return False
def addonlineUsers(username,ip,port):
    if not findUser(username):
        newUser=client(ip,port,username)
        onlineUsers.append(newUser)
        print("Utente aggiunto")
    else:
        print("Utente già online")
def autenticazione(username, password,ip,port):
    utenti = []

    # Carica utenti se file esiste
    if os.path.exists("utentiP2P.json") and os.path.getsize("utentiP2P.json") > 0:
        with open("utentiP2P.json", "r") as filejson:
            utenti = json.load(filejson)

        # Cerco l'utente per login
        for cliente in utenti:
            if cliente["username"] == username:
                if cliente["password"] == password:
                    print("Login riuscito")
                    addonlineUsers(username,ip,port)
                    return True
                else:
                    print("Password errata")
                    return False

        # Se arrivo qui, utente non trovato: lo registro
        new_utente = {"username": username, "password": password}
        utenti.append(new_utente)
        with open("utentiP2P.json", "w") as filejson:
            json.dump(utenti, filejson, indent=4)
        addonlineUsers(username,ip,port)
        print("Registrazione completata")
        return True

    else:
        # File non esiste o vuoto: creo lista e aggiungo utente
        new_utente = {"username": username, "password": password}
        utenti.append(new_utente)
        with open("utentiP2P.json", "w") as filejson:
            json.dump(utenti, filejson, indent=4)
        addonlineUsers(username,ip,port)
        print("Registrazione completata")
        return True
                       

def handle_client(sock):
   #Smistare i messaggi
   samplePack="!20s"
   while True: 
    packData=sock.recv(1024)
    dest=struct.unpack(samplePack,packData)

        #Decodifica i dati ricevuti
    dest=dest[0].decode().strip('\x00')
    if not findUser(dest):
        print("Non è online")
        nack= struct.pack("!i",-5)
        sock.sendall(nack)
    else:
        for destinatario in onlineUsers:
            if destinatario.username==dest:
                print("La porta scelta è ->",destinatario.port)
                ack=struct.pack("!20sI",destinatario.ip.encode().ljust(20,b"\x00"),destinatario.port)
                sock.sendall(ack)
                break
            print("Errore,qualcosa è andato storto")

def Server_message():
    if len(sys.argv)<3:
        print("Servono ip e port del serverMessage")
        return
    server_ip= sys.argv[1]
    server_port=int(sys.argv[2])
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  
    server_socket.bind((server_ip, int(server_port)))

   # configure how many client the server can listen simultaneously
    server_socket.listen(MAX_CLIENTS)

    while True:
       samplePack="!20s20sI"  
       # The server continuously listens for incoming client connections.
       client_socket, address = server_socket.accept()
       print("Connection from: " + str(address))
       packedData=client_socket.recv(1024)
       username,password,port=struct.unpack(samplePack,packedData)
       username=username.decode().strip('\x00')
       password=password.decode().strip('\x00')
       if autenticazione(username,password,address[0],port):
           print("Invio risposta")
           reply=struct.pack("!20s",b'true')
           client_socket.sendall(reply)
           client_thread = threading.Thread(target=handle_client, args=(client_socket,))
           client_thread.start()
       else:
           reply=struct.pack("!20s",b'false')
           client_socket.sendall(reply)
           print("Autenticazione fallita")
       # When a new client connects, a new thread is created to handle the client.
       
  
    conn.close()  # close the connection

if __name__ == '__main__':
   Server_message()
