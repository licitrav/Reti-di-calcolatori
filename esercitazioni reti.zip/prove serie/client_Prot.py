import socket
import struct
import sys
def client_program():
    if len(sys.argv)<3:
        print("Servono ip e port del server")
        return
    server_ip= sys.argv[1]
    server_port=sys.argv[2]

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # instantiate
     # connect to the server

     # take input

    while True:
       calcP = "!Bi10si"
       message = input("Inserisci il comando ")
       if message==str(0):
           dataPacked=struct.pack(calcP,int(message),0,message.encode().ljust(10,b'\x00'),0)
           client_socket.sendto(dataPacked,(server_ip,int(server_port)))   
           print("notifico la chiusura")
       elif message==str(2):
            operazione =input("Inserisci l'operazione ")
            op1=int(input("Inserisci il primo operando "))
            op2=int(input("Inserisci il secondo operando "))
            dataPacked=struct.pack(calcP,int(message),op1,operazione.encode().ljust(10,b'\x00'),op2)
            print("Pacchetto creato") 
            client_socket.sendto(dataPacked,(server_ip,int(server_port))) 
            print("pacchetto inviato") # send message
            data= client_socket.recv(1024)  # receive response
            res=struct.unpack('!i',data)[0]
            print('Received from server: ',res)  # show in terminal
       elif message==str(1):
            dataPacked=struct.pack(calcP,int(message),0,message.encode().ljust(10,b'\x00'),0)
            client_socket.sendto(dataPacked,(server_ip,int(server_port)))
            data= client_socket.recv(1024)  # receive response
            res=struct.unpack('!i',data)[0]   
            print("Il servizio è stato usato :",res)

  # again take input

    client_socket.close()  # close the connection

if __name__ == '__main__':
   client_program()
