import socket
import threading
import sys
import struct
MAX_CLIENTS = 24
#Cambiare handle_clinet in handle_game
#Aspettare il collegamento dei player nel main, e solo dopo aver raggiunto il numero corretto aprire la partita
#Fare una funziona che dia il risultato
#usare .decode e .encode perchè tanto sono stringhe
playerList=[]
class Player:
    def __init__(self,email,password,socket):
        self.email=email
        self.password=password
        self.socket=socket
def access(email,password,socket):
    for player in playerList:
        if player.email==email:
            player.socket=socket
            return True
    newPlayer= Player(email,password,socket)
    playerList.append(newPlayer)
    return True
def result(sock1,sock2,data1,data2):
    if data1=="sasso" and data2=="forbice" or data1=="forbice" and data2=="carta" or data1=="carta" and data2=="sasso" :
        sock1.send(b'win')
        sock2.send(b'lose')
        return 1
    elif data2=="sasso" and data1=="forbice" or data2=="forbice" and data1=="carta" or data2=="carta" and data1=="sasso" :
        sock2.send(b'win')
        sock1.send(b'lose')
        return 1
    else:
        sock2.send(b'draw')
        sock1.send(b'draw')
        return 0
def handle_game():
    gameMatch = []
    gameMatch.append(playerList[0])
    gameMatch.append(playerList[1])
    playerList.remove(playerList[0])
    playerList.remove(playerList[0])
    print("[SERVER] Inizio partita tra:", gameMatch[0].email, "e", gameMatch[1].email)
    vittorie = [0, 0]
    sconfitte = [0, 0]
    while True:
        # Ricevi le mosse
        data1 = gameMatch[0].socket.recv(1024).decode().strip().replace('\x00','')
        if not data1:
            print("[SERVER] Disconnessione player 1")
            gameMatch[0].socket.close()
            return
        data2 = gameMatch[1].socket.recv(1024).decode().strip().replace('\x00','')
        if not data2:
            print("[SERVER] Disconnessione player 2")
            gameMatch[1].socket.close()
            return
        print(f"[SERVER] Ricevute mosse: {data1} vs {data2}")
        # Calcola risultato
        res = result(gameMatch[0].socket, gameMatch[1].socket, data1, data2)
        if res == 1:
            if (data1 == "sasso" and data2 == "forbice") or (data1 == "forbice" and data2 == "carta") or (data1 == "carta" and data2 == "sasso"):
                vittorie[0] += 1
                sconfitte[1] += 1
            else:
                vittorie[1] += 1
                sconfitte[0] += 1
        # Controlla se qualcuno ha vinto
        if vittorie[0] >= 3 or vittorie[1] >= 3:
            print("[SERVER] Partita finita")
            # Dopo la partita
            risposte = []
            for i in range(2):
                risposta = gameMatch[i].socket.recv(1024).decode().strip()
                risposte.append(risposta)

            if risposte[0] == 's' and risposte[1] == 's':
                vittorie = [0, 0]
                sconfitte = [0, 0]
                continue  # entrambi vogliono rigiocare
            
            # Se solo uno vuole rigiocare, rimettilo in playerList
            for i in range(2):
                if risposte[i] == 's':
                    playerList.append(gameMatch[i])
                    number= struct.pack("!i",1)
                    gameMatch[i].socket.send(number)
                else:
                    gameMatch[i].socket.close()
            # Esci dal ciclo partita
            gameMatch.clear()
            break
        

    
def server_program():
    if len(sys.argv)<3:
       print("Servono Ip e porta del server")
       return
    host = sys.argv[1]
    port = int(sys.argv[2])
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  
    server_socket.bind((host, port))

    # configure how many client the server can listen simultaneously
    server_socket.listen(MAX_CLIENTS)
    sampleStruct="!30s30s"
    while True:
        # The server continuously listens for incoming client connections.
        client_socket, address = server_socket.accept()
        print("Connection from: " + str(address))
        packet=client_socket.recv(1024)
        emailP,passwordP=struct.unpack(sampleStruct,packet)
        emailP=emailP.decode().strip('\x00')
        passwordP=passwordP.decode().strip('\x00')
        if access(emailP,passwordP,client_socket):
            print("Login riuscito")
            
        if len(playerList)==1:
            pack=struct.pack("!i",1)
            client_socket.send(pack)
            risp=client_socket.recv(1024).decode()
            print("Risposta",risp)
            if risp=='s':
                continue
            else:
                playerList.remove(playerList[0])
        elif len(playerList)==2:
            pack=struct.pack("!i",2)
            client_socket.send(pack)
            playerList[0].socket.send(pack)
            client_thread = threading.Thread(target=handle_game, args=())
            client_thread.start()
        else:
            print("Errore riprovare")
            client_socket.close()

        
    
    conn.close()  # close the connection

if __name__ == '__main__':
   server_program()

