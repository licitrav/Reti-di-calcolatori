 #include <stdint.h>

#define LEN 32
#define MSG_LEN 256

#pragma pack(push, 1)
typedef struct {
   uint8_t command;  // 0=normal, 1=register, 2=exit
   char operation[LEN];
   int op1;
   int op2;
} calc;
#pragma pack(pop)
