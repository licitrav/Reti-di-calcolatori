import socket
import threading
import os
import sys
import json
import struct
import random
MAX_CLIENTS = 24
lobby=[]
class giocatore:
   def __init__(self,username,password):
      self.username=username
      self.password=password
class giocatoreAttivo:
    def __init__(self,username,ruolo,socket):
      self.username=username
      self.ruolo=ruolo
      self.socket=socket
def autenticazione(username,password):
   players=[]
   if os.path.exists("player.json") and os.path.getsize("player.json")>0:
      with open("player.json","r") as filejson:
         players=json.load(filejson)
         for player in players:
            if player["username"]==username:
                    if player["password"]==password:
                        print("Login effettuato")
                        return True
                    else:
                       print("Accesso errato")
                       return False
         print("Aggiungo il nuovo player")
      with open("player.json","a") as filejson:
          newPlayer= giocatore(username,password)
          json.dump(newPlayer,filejson,indent=4)
   else:
        print("Creo il file")
        with open("player.json","w") as filejson:
            newPlayer= giocatore(username,password)
            players.append(newPlayer)
            json.dump(players,filejson,indent=4)
def result(data1,data2):
    if data1+data2%2==0: return "paro"
    else: return "sparo"
def handle_game():
   while True:
    gameMatch=[]
    gameMatch.append(lobby[0])
    gameMatch.append(lobby[1])
    lobby.remove(lobby[1])
    lobby.remove(lobby[0])
    print("Assegnazione pari e dispari")
    if random.randint(1,10)%2==0:
        gameMatch[0].ruolo='paro'
        gameMatch[1].ruolo='sparo'
        packrisp1=struct.pack('!c',b'p')
        packrisp2=struct.pack('!c',b'd')
        gameMatch[0].socket.send(packrisp1)
        gameMatch[1].socket.send(packrisp2)
    else:
        gameMatch[1].ruolo='paro'
        gameMatch[0].ruolo='sparo'
        packrisp2=struct.pack('!c',b'p')
        packrisp1=struct.pack('!c',b'd')
        gameMatch[0].socket.send(packrisp1)
        gameMatch[1].socket.send(packrisp2)
    vittorie=[0,0]
    sconfitte=[0,0]
    while vittorie>=3 and sconfitte>=3:
            data1 = gameMatch[0].socket.recv(1024).decode()
            data2 = gameMatch[1].socket.recv(1024).decode()
            unpackdata1=struct.unpack('!i',data1)
            unpackdata2=struct.unpack('!i',data2)
            print("from connected players: " , unpackdata1,unpackdata2)
            if result(unpackdata1,unpackdata2)==gameMatch[0].ruolo:
                packres1=struct.pack('!c',b'w')
                packres2=struct.pack('!c',b'l')
                gameMatch[0].socket.send(packres1)
                gameMatch[1].socket.send(packres2)
                vittorie[0]+=1
                sconfitte[1]+=1
            else:
                packres2=struct.pack('!c',b'w')
                packres1=struct.pack('!c',b'l')
                gameMatch[0].socket.send(packres1)
                gameMatch[1].socket.send(packres2)
                vittorie[1]+=1
                sconfitte[0]+=1
    print("Partita finita,aspetto chi vuole rigiocare")
    risposte=[]
    for i in range(2):
                risposta = gameMatch[i].socket.recv(1024).decode()
                risposte.append(risposta)

                if risposte[0] == 's' and risposte[1] == 's':
                    vittorie = [0, 0]
                    sconfitte = [0, 0]
                    continue  # entrambi vogliono rigiocare
            
            # Se solo uno vuole rigiocare, rimettilo in playerList
                for i in range(2):
                    if risposte[i] == 's':
                        lobby.append(gameMatch[i])
                        number= struct.pack("!i",1)
                        gameMatch[i].socket.send(number)
                    else:
                        gameMatch[i].socket.close()
            # Esci dal ciclo partita
                        gameMatch.clear()
                    break

    
   

def server_program():
  if len(sys.argv)<3:
    print("Metti ip e porta del server")
  host = sys.argv[1]
  port = int(sys.argv[2])
  server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  
  server_socket.bind((host, port))

   # configure how many client the server can listen simultaneously
  server_socket.listen(MAX_CLIENTS)

  while True:
       # The server continuously listens for incoming client connections.
       client_socket, address = server_socket.accept()
       print("Connection from: " + str(address))
       sampleReg= "!30s30s"
       packReg= client_socket.recv(1024)
       username,password=struct.unpack(sampleReg,packReg)
       username=username.decode().strip('\x00')
       password=password.decode().strip('\x00')
       if autenticazione(username,password):
           newPlayer=giocatoreAttivo(username," ",client_socket)
           lobby.append(newPlayer)
           sampleSend="!ic"
           packSend=struct.pack(sampleSend,len(lobby),b'c')
           client_socket.sendall(packSend)
           packc=client_socket.recv(1024)
           char=struct.unpack('!c',packc)
           char.decode()
           if char=='s':
               print("Rimane in attesa")
               continue
           else:
               print("Leviamolo")
               lobby.remove(newPlayer)
               client_socket.close
       if len(lobby)==2:
        client_thread = threading.Thread(target=handle_game, args=())
        client_thread.start()
  
  conn.close()  # close the connection

if __name__ == '__main__':
   server_program()

