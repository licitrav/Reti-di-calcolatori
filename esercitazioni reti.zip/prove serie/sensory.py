import socket
import pickle
import random
import sys
import time
from sensore import sensore
#Crea il sensore e i suoi risultati, li invia al centralNode
#Comunica solo con lui
#Quando entra in allarme aspetta una recv, dopo che la riceve il risultato, si sblocca
#Connessione TCP
def createSensor():
   return sensore(0,0,0,random.randint(1000,5000))
def assingValue(sensor):
     sensor.temperatura,sensor.umidità,sensor.qualAir=(random.randint(0,100),random.randint(0,100),random.randint(0,100))
def client_program():
   if len(sys.argv)<3:
        print("Scrivere ip e porta del centralNode")
    
   host = sys.argv[1] 
   port = int(sys.argv[2])

   client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # instantiate
   client_socket.connect((host, port))  # connect to the server
   sensor=createSensor()
   packSensor=pickle.dumps(sensor.id)
   client_socket.sendall(packSensor)
   idres=client_socket.recv(1024)
   unid=pickle.loads(idres)
   if unid == sensor.id:
           print("Id ok")
   else:
           sensor.id=unid
   while True :
       print("Nuova iterazione")
       assingValue(sensor)
       packSensor=pickle.dumps(sensor)
       client_socket.sendall(packSensor)
       
       print("Risultati del sensore ",sensor.temperatura,sensor.umidità,sensor.qualAir,sensor.id)
       if sensor.temperatura>30 or sensor.qualAir<30:
            print("Alarm mode")
            data = client_socket.recv(1024).decode()
            if data=='backnormal':
                print("Tutto sotto controllo")
            else: 
                print("Funniu")
                break
       print("Ciclo finito")
       time.sleep(3)
   client_socket.close()  # close the connection

if __name__ == '__main__':
   client_program()
