import socket
import struct
import sys
import threading
import pickle
from protPY import calc
#Client-> LB-> MC
MAX_CLIENTS=24
calculators=[]
global i
i=0
def get_next_calculator_ip():
    global i
    microServiceIP = calculators[i][1]
    microServicePort=calculators[i][2]
    i = (i + 1) % len(calculators)  # loop circolare
    return (microServiceIP,microServicePort)
def handle_client(client_socket):
    #socket tcp
   # receive data stream.
   #Riceve il pacchetto da passare alla funzione server
   while True: 
    data = client_socket.recv(1024)
    
    if not data:
        # if data is not received break
        client_socket.close()
        return
    print("from connected user: " + str(data))
    request=pickle.loads(data)
    calculators.append((request.IDc,request.IPc,request.portC))
    result=struct.pack('!i',int(handle_server(request)))
    #Mandare il risultato ->->->

    client_socket.send(result) 
    print("Pacchetto inviato, contiene",result)
   client_socket.close()
def handle_server(request):
    #Assegnamo gli  Ip in maniera dinamica
    
    
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # instantiate
     # connect to the server
    microServiceIP,microServicePort=get_next_calculator_ip()
     # take input

    while True:
       calcP = "!Bi10si"
       
       if request.command==0:
           dataPacked=struct.pack(calcP,int(request.command),0,request.operazione.encode().ljust(10,b'\x00'),0)
           client_socket.sendto(dataPacked,(microServiceIP,microServicePort))   
           return -9999
       elif request.command==2:
            dataPacked=struct.pack(calcP,int(request.command),request.op1,request.operazione.encode().ljust(10,b'\x00'),request.op2)
            print("Pacchetto creato") 
            client_socket.sendto(dataPacked,(microServiceIP,microServicePort)) 
            print("pacchetto inviato") # send message
            data= client_socket.recv(1024)  # receive response
            res=struct.unpack('!i',data)[0]
            print('Received from server: ',res)
            return res  # show in terminal
       elif request.command==1:
            dataPacked=struct.pack(calcP,request.command,0,request.operazione.encode().ljust(10,b'\x00'),0)
            client_socket.sendto(dataPacked,(microServiceIP,microServicePort))
            data= client_socket.recv(1024)  # receive response
            res=struct.unpack('!i',data)[0]   
            print("Il servizio è stato usato :",res)
            return res

  # again take input

    client_socket.close()  # close the connection

def load_Balancer():
    if len(sys.argv)<3:
        print("Servono ip e port del load balancer")
        return
    server_ip= sys.argv[1]
    server_port=sys.argv[2]

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  
    server_socket.bind((server_ip, int(server_port)))

   # configure how many client the server can listen simultaneously
    server_socket.listen(MAX_CLIENTS)

    while True:
       # The server continuously listens for incoming client connections.
       client_socket, address = server_socket.accept()
       print("Connection from: " + str(address))
       # When a new client connects, a new thread is created to handle the client.
       client_thread = threading.Thread(target=handle_client, args=(client_socket,))
       client_thread.start()
  
    conn.close()  # close the connection

if __name__ == '__main__':
   load_Balancer()
