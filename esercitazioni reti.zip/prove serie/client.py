import socket
import pickle
import sys
import struct
from protPY import calc
def client_program():
    if len(sys.argv)<6:
        print("Servono ip e port del server e IP,port e ID del calculator")
        return
    server_ip= sys.argv[1]
    server_port=sys.argv[2]

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # instantiate
     # connect to the server
    client_socket.connect((server_ip, int(server_port))) 
     # take input

    while True:
        message = input("Inserisci il comando ")
        operazione =input("Inserisci l'operazione ")
        op1=int(input("Inserisci il primo operando "))
        op2=int(input("Inserisci il secondo operando "))
        print("Pacchetto creato") 
        dataRaw=calc(int(message),int(op1),int(op2),operazione,int(sys.argv[4]),sys.argv[3],int(sys.argv[5]))
        dataPacked=pickle.dumps(dataRaw)
        client_socket.sendall(dataPacked) 
        print("pacchetto inviato") # send message
        dataPack=client_socket.recv(1024) # receive response
        data=struct.unpack('!i',dataPack)
        print('Received from server: ',data[0])  # show in terminal
        
        
          # receive response

  # again take input

    client_socket.close()  # close the connection

if __name__ == '__main__':
   client_program()
