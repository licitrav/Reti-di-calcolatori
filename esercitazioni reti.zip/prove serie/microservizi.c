#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include "calc_prot.h"

#define MAX_CLIENTS 10
int counter_use=0;


//pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
int operation(calc standard){
    if(strcmp(standard.operation,"add")==0) return standard.op1+standard.op2;
    else if (strcmp(standard.operation,"sottr")==0) return standard.op1-standard.op2;
    else if(strcmp(standard.operation,"molt")==0) return standard.op1*standard.op2;
    else if(strcmp(standard.operation,"div")==0) return standard.op1/standard.op2;
    else{
        printf("Comando errato\n");
        return INT16_MIN;
    }
}
int main(int argc, char *argv[]){
    if(argc<3){
        perror("Servono Ip e porta del server\n");
        return -1;
    }
   int sockfd;
   struct sockaddr_in server_addr, client_addr;
   socklen_t addr_len = sizeof(client_addr);
   

   // create UDP socket
   if((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
       perror("socket failed");
       return 1;
   }

   memset(&server_addr, 0, sizeof(server_addr));
   server_addr.sin_family = AF_INET;
   if(inet_pton(AF_INET,argv[1],&server_addr.sin_addr.s_addr)<0){
        perror("invalid address");
        exit(1);

   }
   server_addr.sin_port = htons(atoi(argv[2]));

   if(bind(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
       perror("bind failed");
       return 2;
   }

   printf("UDP Calc Server running on port %s\n", argv[2]);
   uint8_t buffer[19];
   while(1) {
       // Receive message
       ssize_t bytes = recvfrom(sockfd, &buffer, sizeof(buffer), 0,
                              (struct sockaddr*)&client_addr, &addr_len);
        printf("Arrivato qualcosa\n");
        calc operazione;
        memcpy(&operazione.command,buffer,1);
        if(operazione.command==0){
            printf("Chiusura del microservizio");
            close(sockfd);
            return 1;
        }
        else if(operazione.command==1){
            printf("Mostro il numero di volte di utilizzo del servizio di calcolo");
            int packed_counter=ntohl(counter_use);
            sendto(sockfd,&packed_counter,sizeof(int),0,(struct sockaddr*)&client_addr, sizeof(client_addr));
        }
        else{
        memcpy(&operazione.op1, buffer+1, 4);
        operazione.op1=ntohl(operazione.op1);
        memcpy(&operazione.operation, buffer + 5, 10);
        memcpy(&operazione.op2, buffer + 15, 4);
        operazione.op2=ntohl(operazione.op2);
        printf("Arrivato %d %s %d\n",operazione.op1,operazione.operation,operazione.op2);
        int res=htonl(operation(operazione));
        //int res=0;
        printf("Sto inviando %d\n",res);
        sendto(sockfd,&res,sizeof(int),0,(struct sockaddr*)&client_addr, sizeof(client_addr));
        counter_use++;
    }
   }

   return 0;
}
